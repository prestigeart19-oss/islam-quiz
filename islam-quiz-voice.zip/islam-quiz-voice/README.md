# 🕌 ISLAM QUIZ - Version avec Assistant Vocal IA

## 🎙️ Nouvelle fonctionnalité : Conversation vocale complète !

Quiz islamique interactif avec un assistant vocal intelligent qui vous accompagne tout au long du jeu en français.

## ✨ Fonctionnalités de l'Assistant Vocal

### 🗣️ L'IA vocale peut :
- **Vous accueillir** au démarrage de l'application
- **Lire chaque question** à voix haute
- **Écouter vos réponses** vocales (en plus des boutons)
- **Commenter vos réponses** : "Bravo !", "Excellent !", "Courage !"
- **Encourager** entre les questions
- **Annoncer vos résultats** à la fin de chaque niveau

### 🎯 Comment utiliser l'assistant vocal ?

1. **Activer l'assistant** : Cliquez sur le bouton 🔊 en haut à droite
2. **Écouter les questions** : L'IA lit automatiquement chaque question
3. **Répondre vocalement** : 
   - Cliquez sur le bouton 🎤 "Répondre vocalement"
   - Dites votre réponse à voix haute
   - L'IA reconnaît votre réponse et la valide automatiquement
4. **Répondre par clic** : Vous pouvez toujours cliquer sur les boutons si vous préférez

### 🎮 Fonctionnalités du Quiz

- ✅ **200 niveaux** de difficulté progressive
- ✅ **10 questions par niveau** sur l'Islam
- ✅ **Chronomètre de 30 secondes** par question
- ✅ **Système de points** : Plus vous êtes rapide, plus vous gagnez de points !
- ✅ **Statistiques détaillées** de votre progression
- ✅ **Sauvegarde automatique** de votre progression
- ✅ **PWA** : Installez l'app sur votre téléphone !

### 📱 Technologies utilisées

- **HTML5, CSS3, JavaScript** (Vanilla)
- **Web Speech API** pour la reconnaissance vocale
- **Speech Synthesis API** pour la synthèse vocale
- **LocalStorage** pour la sauvegarde
- **PWA** (Progressive Web App)

### 🚀 Installation

#### En ligne :
1. Visitez le site hébergé
2. Cliquez sur le bouton "Installer" dans votre navigateur
3. L'application s'installe comme une vraie app !

#### En local :
1. Clonez le repository
2. Ouvrez `index.html` dans votre navigateur
   - Utilisez Chrome, Edge ou Safari pour la meilleure compatibilité vocale

### 🎤 Compatibilité vocale

| Navigateur | Reconnaissance vocale | Synthèse vocale |
|------------|---------------------|----------------|
| Chrome     | ✅ Excellente       | ✅ Excellente  |
| Edge       | ✅ Excellente       | ✅ Excellente  |
| Safari     | ❌ Non supportée    | ✅ Bonne       |
| Firefox    | ❌ Non supportée    | ✅ Limitée     |

**Recommandation** : Utilisez Chrome ou Edge pour profiter pleinement de l'assistant vocal.

### 📂 Structure des fichiers

```
islam-quiz-voice/
├── index.html              # Page principale
├── app.js                  # Logique du jeu
├── voice-ai.js            # Module d'IA vocale (NOUVEAU !)
├── questions.js           # Base de données des questions
├── style.css              # Styles CSS (avec styles vocaux)
├── manifest.json          # Configuration PWA
├── service-worker-1.js    # Service Worker pour PWA
├── icon-192-3.png         # Icône 192x192
├── icon-512-3.png         # Icône 512x512
└── README.md              # Ce fichier
```

### 🎨 Personnalisation

#### Changer la vitesse de la voix :
Dans `voice-ai.js`, ligne ~45 :
```javascript
utterance.rate = 1.0; // Changez entre 0.5 et 2.0
```

#### Ajouter des phrases personnalisées :
Dans `voice-ai.js`, modifiez les tableaux de messages :
```javascript
const greetings = [
    'Assalam alaykoum !',
    'Votre propre message...'
];
```

### 🔧 Dépannage

**L'assistant ne parle pas** :
- Vérifiez que le bouton 🔊 est activé (vert)
- Vérifiez le volume de votre appareil
- Essayez un autre navigateur (Chrome recommandé)

**La reconnaissance vocale ne fonctionne pas** :
- Autorisez l'accès au microphone dans votre navigateur
- Utilisez Chrome ou Edge
- Vérifiez que votre microphone fonctionne

**L'application ne s'installe pas** :
- Assurez-vous d'utiliser HTTPS ou localhost
- Vérifiez que le service worker est bien enregistré

### 🌟 Améliorations futures possibles

- [ ] Voix plus naturelles avec API externe (ElevenLabs)
- [ ] Support multilingue (arabe, anglais)
- [ ] Conversation bidirectionnelle complète
- [ ] Explications détaillées des réponses
- [ ] Mode révision avec l'IA

### 📝 License

Ce projet est open source. Utilisez-le librement pour apprendre et partager la connaissance islamique !

---

**Qu'Allah vous bénisse dans votre apprentissage ! 🤲**

*"Recherchez la connaissance du berceau jusqu'à la tombe"* - Hadith
